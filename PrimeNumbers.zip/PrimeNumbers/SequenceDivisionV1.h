#pragma once

#include "util.h"
#include "PrimeNumbersResult.h"
#include <iostream>

void performSequenceDivisionV1Primes(PrimeNumbersResult& primeNumberResult);
