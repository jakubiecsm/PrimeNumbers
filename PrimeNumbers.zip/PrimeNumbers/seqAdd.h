#pragma once

#include "util.h"


void seqAdd(const int LOWER_BOUND, const int HIGHER_BOUND);

