#pragma once

#include "util.h"


void seqDiv1(const int LOWER_BOUND, const int HIGHER_BOUND);
void seqDiv2(const int LOWER_BOUND, const int HIGHER_BOUND);
void seqDivPrimes1(const int LOWER_BOUND, const int HIGHER_BOUND);