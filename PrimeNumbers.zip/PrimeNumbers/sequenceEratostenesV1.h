#pragma once

#include "util.h"
#include "PrimeNumbersResult.h"
#include <iostream>

void performSequenceEratostenesV1(PrimeNumbersResult& primeNumbersResult);