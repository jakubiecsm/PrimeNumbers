#pragma once

#include "util.h"


namespace parallelDivisionCommon {

	bool isNumberPrime(int number);

}


