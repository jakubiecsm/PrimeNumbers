#pragma once

#include "util.h"
#include "PrimeNumbersResult.h"
#include <iostream>

//Even numbers (except of 2) cannot be prime
void performSequenceDivisionV2Primes(PrimeNumbersResult& primeNumberResult);
